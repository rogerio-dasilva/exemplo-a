package br.com.bb.mci;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ClientesDAO {
	private List<Cliente> listaClientes;
	
	public ClientesDAO() {
		listaClientes = new ArrayList<Cliente>();
		listaClientes.add(new Cliente(1, "João", "123465-9", new TipoDocumento(1, "RG")));
		listaClientes.add(new Cliente(2, "Maria","123.456.789-12", new TipoDocumento(1, "CPF")));
	}

	public List<Cliente> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}
}
