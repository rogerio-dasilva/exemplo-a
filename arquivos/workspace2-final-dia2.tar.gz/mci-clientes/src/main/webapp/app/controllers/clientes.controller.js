angular.module('clientes').controller('ClientesController', function($scope, $http, $location, $rootScope) {
    $scope.selecionado = {};
    
    if($rootScope.selecionado){
        $scope.selecionado = $rootScope.selecionado;
    }

	$scope.lista = function(){
		$http.get('/mci-clientes-api/api/clientes')
		.success(function(retorno){
			$scope.clientes = retorno.listaClientes;
		}).error(function(erro){
			console.log(JSON.stringify(erro));
			var id = '#msgDanger';
	        $(id).text(erro);
	        $(id).css('display', 'block');
	        setTimeout(function () {
	            $(id).css('display', 'none');
	        }, 5000);
		});

	}

	$scope.novo = function(){
		$rootScope.selecionado = null;
		$location.url('/edicao');
	}


	$scope.voltar = function(){
		$location.url('/clientes');
	};
	
	$scope.incluir = function(){
		$http.post('/mci-clientes-api/api/clientes', $scope.selecionado)
		.success(function(retorno){
			$location.url('/clientes');
		}).error(function(erro){
			console.log(JSON.stringify(erro));
			var id = '#msgDanger';
	        $(id).text(erro);
	        $(id).css('display', 'block');
	        setTimeout(function () {
	            $(id).css('display', 'none');
	        }, 5000);
		});
	}
	
	$scope.selecionar = function(cliente){
		$rootScope.selecionado = cliente;
		$location.url('/edicao');
	}
	
	$scope.alterar = function(){
		$http.put('/mci-clientes-api/api/clientes/' + $scope.selecionado.mci, $scope.selecionado)
		.success(function(retorno){
			$location.url('/clientes');
		}).error(function(erro){
			var id = '#msgDanger';
	        $(id).text(erro);
	        $(id).css('display', 'block');
	        setTimeout(function () {
	            $(id).css('display', 'none');
	        }, 5000);
		});
		
	}
	
	 $scope.detalhar = function(cliente){
	        $rootScope.selecionado = cliente;
	        $location.url('/detalhe');
	    };
	    
	    $scope.confirmarExclusao = function(cliente){
	        $rootScope.selecionado = cliente;
	        $location.url('/exclusao');
	    };
	 
	$scope.excluir = function(){
	        $http.delete('/mci-clientes-api/api/clientes/' + $scope.selecionado.mci)
	        .success(function(retorno){
	            $location.url('/clientes');
	        }).error(function(erro){
	            console.log(JSON.stringify(erro));
	            var id = '#msgDanger';
	            $(id).text(erro);
	            $(id).css('display', 'block');
	            setTimeout(function () {
	                $(id).css('display', 'none');
	            }, 5000);
	        });
	       
	    }
	
	$scope.salvar = function(){
		if($scope.selecionado.mci){
			$scope.alterar();
		} else {
			$scope.incluir();
		}
	}

	$scope.lista();

});