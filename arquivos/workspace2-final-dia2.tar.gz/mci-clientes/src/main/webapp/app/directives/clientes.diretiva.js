angular.module('minhasDiretivas', []).directive('bbPainel', function(){
	var ddo = {};
	ddo.restrict = 'AE';
	ddo.scope = {
			item: '='
	};
	ddo.transclude = true;
	ddo.template = '<div class="panel panel-default">'
//		+ '<div style="width: 50px; float: left;">{{item.mci}}</div>'
//		+ '<div style="width: 50px; float: left;">{{item.nome}}</div>'
		+ '<div ng-transclude > </div> <span ng-click="alert("aqui" + item.mci);">Editar</span> '
		+ '</div>';
	return ddo;
});