angular.module('clientes', ['ngRoute']).config(function($routeProvider){
	$routeProvider.when('/clientes', {
		templateUrl: 'partials/principal.html',
		controller: 'ClientesController'
	});
	
	$routeProvider.when('/edicao', {
		templateUrl: 'partials/edicao.html',
		controller: 'ClientesController'
	});
	
	$routeProvider.when('/detalhe', {
		templateUrl: 'partials/detalhe.html',
		controller: 'ClientesController'
	});
	
	$routeProvider.when('/exclusao', {
		templateUrl: 'partials/exclusao.html',
		controller: 'ClientesController'
	});
	
	$routeProvider.otherwise({ 
		templateUrl: 'partials/principal.html',
		controller: 'ClientesController'
	});
});