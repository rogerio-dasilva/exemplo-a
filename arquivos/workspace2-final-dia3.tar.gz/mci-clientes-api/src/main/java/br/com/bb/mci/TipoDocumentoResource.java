package br.com.bb.mci;


import java.util.ArrayList;
import java.util.List;

public class TipoDocumentoResource {
	private List<TipoDocumento> listaTipoDocumento;

	public TipoDocumentoResource() {
		listaTipoDocumento = new ArrayList<TipoDocumento>();
		listaTipoDocumento.add(new TipoDocumento(1, "Identidade"));
		listaTipoDocumento.add(new TipoDocumento(2, "Carteira de Motorista"));
		listaTipoDocumento.add(new TipoDocumento(3, "Certidão de Nascimento"));
	}

	public List<TipoDocumento> listar() {
		return listaTipoDocumento;
	}

	public TipoDocumento detalhar(Integer id) {
		for (TipoDocumento td : listaTipoDocumento) {
			if (td.getCodigo() == id) {
				return td;
			}
		}
		return null;
	}
}
