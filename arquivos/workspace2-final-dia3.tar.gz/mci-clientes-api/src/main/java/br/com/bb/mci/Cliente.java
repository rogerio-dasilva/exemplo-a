package br.com.bb.mci;

import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement()
public class Cliente {
	private Integer mci;
	private String nome;
	private String documento;
	private TipoDocumento tipoDocumento;
	private java.util.Date incluido;
	private java.util.Date alteracao;

	
	public Cliente() {
	}
	
	public Cliente(Integer codigo, String nome) {
		this.mci = codigo;
		this.nome = nome;
	}
	
	public Cliente(Integer codigo, String nome, String documento, TipoDocumento tipo) {
		this.mci = codigo;
		this.nome = nome;
		this.documento = documento;
		this.tipoDocumento = tipo;
	}

	public Integer getMci() {
		return mci;
	}

	public void setMci(Integer codigo) {
		this.mci = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documentoIdentificacao) {
		this.documento = documentoIdentificacao;
	}

	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public java.util.Date getIncluido() {
		return incluido;
	}

	public void setIncluido(java.util.Date incluido) {
		this.incluido = incluido;
	}

	public java.util.Date getAlteracao() {
		return alteracao;
	}

	public void setAlteracao(java.util.Date alteracao) {
		this.alteracao = alteracao;
	}
}
