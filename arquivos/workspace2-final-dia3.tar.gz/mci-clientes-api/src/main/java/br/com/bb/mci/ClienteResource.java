package br.com.bb.mci;

import java.util.Date;
import java.util.ListIterator;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@RequestScoped
@Path("clientes")
public class ClienteResource {

	@Inject
	private ClientesDAO clientesDAO;

	public ClienteResource() {
	}

	// curl -i -H "Accept: application/json" -X GET http://localhost:7001/mci-clientes-api/api/clientes -v
	@GET
//	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public Response listar() {
		return Response.ok()
				.entity(new Clientes(clientesDAO.getListaClientes())).build();
	}

	// curl -i -H "Accept: application/json" -X  GET http://localhost:7001/mci-clientes-api/api/clientes/1 -v
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response detalhar(@PathParam("id") Integer id) {
		for (Cliente c : clientesDAO.getListaClientes()) {
			if (c.getMci().equals(id)) {
				return Response.ok()
						.entity(c).build();
			}
		}

		return Response.status(404).build();
	}

	// curl -X PUT -H "Accept: Application/json" -H "Content-Type: application/json" http://localhost:7001/mci-clientes-api/api/clientes/1 -d '{"id" : 1, "nome":"Ricardo"}' -v
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Response alterar(@PathParam("id") Integer id, Cliente cliente) {
		for (Cliente c : clientesDAO.getListaClientes()) {
			if (c.getMci().equals(id)) {
				c.setNome(cliente.getNome());
				c.setDocumento(cliente.getDocumento());
				if(cliente.getTipoDocumento() != null){
					c.setTipoDocumento(cliente.getTipoDocumento());
				}
				c.setAlteracao(new Date());
				return Response.ok().entity(c).build();
			}
		}

		return Response.status(404).build();
	}

	// curl -X POST -H "Accept: Application/json" -H "Content-Type: application/json" http://localhost:7001/mci-clientes-api/api/clientes/1 -d '{"nome":"Ricardo"}' -v
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response incluir(Cliente cliente) {
		Integer novoCodigo = 0;
		for (Cliente c : clientesDAO.getListaClientes()) {
			if (novoCodigo <= c.getMci()) {
				novoCodigo = c.getMci() + 1;
			}
		}

		cliente.setMci(novoCodigo);
		cliente.setIncluido(new Date());

		clientesDAO.getListaClientes().add(cliente);

		return Response.status(201).entity(cliente).build();
	}

	// curl -X DELETE -H "Accept: Application/json" http://localhost:7001/mci-clientes-api/api/clientes/1 -v
	@DELETE
	@Path("/{id}")
	public Response apagar(@PathParam("id") Integer id) {
		ListIterator<Cliente> iter = clientesDAO.getListaClientes().listIterator();
		while(iter.hasNext()){
		    if(iter.next().getMci().equals(id)){
		        iter.remove();
		        return Response.ok().build();
		    }
		}

		return Response.status(404).build();
	}
}
