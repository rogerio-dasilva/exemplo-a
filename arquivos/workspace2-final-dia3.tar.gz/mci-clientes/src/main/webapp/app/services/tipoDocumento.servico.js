angular.module('clientes').factory('TiposDocumentosService', function($http){
	var service = {};
	
	service.listar = function(resolve,reject){
		resolve([
				    {'codigo' : 1, 'descricao': 'Registro Geral' },
				    {'codigo' : 2, 'descricao': 'Cadastro de Pessoa Física' }
				]);
	}
	

	
	return service;
});
