angular.module('clientes').factory('ClientesService', function($http){
	var service = {};
	
	service.listar = function(resolve,reject){
		$http.get('/mci-clientes-api/api/clientes').success(function(retorno){
			resolve(retorno.listaClientes);
		}).error(function(erro){
			reject(erro);
		});
	}
	
	service.recuperar = function(mci,resolve,reject){
		$http.get('/mci-clientes-api/api/clientes/' + mci).success(function(retorno){
			resolve(retorno);
		}).error(function(erro){
			reject(erro);
		});
	}
	
	service.incluir = function(cliente, resolve, reject) {
		$http.post('/mci-clientes-api/api/clientes', cliente)
		.success(function(retorno){
			resolve();
		}).error(function(erro){
			reject(erro);
		});
	}
	
	service.alterar = function(cliente, resolve, reject){
		$http.put('/mci-clientes-api/api/clientes/' + cliente.mci, cliente)
		.success(function(retorno){
			resolve();
		}).error(function(erro){
			reject(erro);
		});
	}
	
	service.excluir = function(mci, resolve, reject){
        $http.delete('/mci-clientes-api/api/clientes/' + mci)
        .success(function(retorno){
        	resolve();
        }).error(function(erro){
        	reject(erro);
        });
    } 
	
	return service;
});
