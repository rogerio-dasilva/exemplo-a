angular.module('clientes').controller('TiposDocumentosController', function($scope, $http, $location, $rootScope, TiposDocumentosService) {
	
    $scope.tiposDocumentos = {};
    
    $scope.exibirErro = function (erro) {
		var id = '#msgDanger';
        $(id).text(erro);
        $(id).css('display', 'block');
        setTimeout(function () {
            $(id).css('display', 'none');
        }, 5000);
	}
    
	$scope.listaTiposDocumentos = function(){
		TiposDocumentosService.listar(function(lista){
			$scope.tiposDocumentos = lista;
		},function(erro){
			$scope.exibirErro(erro);
		});
		
	}

	$scope.listaTiposDocumentos();

});