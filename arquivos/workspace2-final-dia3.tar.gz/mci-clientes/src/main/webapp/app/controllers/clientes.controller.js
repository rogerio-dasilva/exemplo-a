angular.module('clientes').controller('ClientesController', function($scope, $http, $location, $rootScope, ClientesService) {
	
	
    $scope.selecionado = {};
    $scope.tiposDocumentos = {};
    
    
    $scope.exibirErro = function (erro) {
		var id = '#msgDanger';
        $(id).text(erro);
        $(id).css('display', 'block');
        setTimeout(function () {
            $(id).css('display', 'none');
        }, 5000);
	}
    
    if($rootScope.selecionado){
        $scope.selecionado = $rootScope.selecionado;
    }

	$scope.lista = function(){
		ClientesService.listar(function(clientes){
			$scope.clientes = clientes;
		}, function(erro){
			$scope.exibirErro(erro);
		});
	}

	$scope.novo = function(){
		$rootScope.selecionado = null;
		$location.url('/edicao');
	}


	$scope.voltar = function(){
		$location.url('/clientes');
	};
	
	$scope.incluir = function(){
		ClientesService.incluir($scope.selecionado, function(){
			$location.url('/clientes');
		},function(erro){
			$scope.exibirErro(erro);
		});
	}
	
	$scope.selecionar = function(cliente){
		ClientesService.recuperar(cliente.mci, function(resposta){
			$rootScope.selecionado = resposta;
			$location.url('/edicao');
		},function(erro){
			$scope.exibirErro(erro);
		});
	}
	
	$scope.alterar = function(){
		ClientesService.alterar($scope.selecionado, function(){
			$location.url('/clientes');
		},function(erro){
			$scope.exibirErro(erro);
		});
	}
	
	 $scope.detalhar = function(cliente){
        ClientesService.recuperar(cliente.mci, function(resposta){
			$rootScope.selecionado = resposta;
			$location.url('/detalhe');
		},function(erro){
			$scope.exibirErro(erro);
		});
    };
	    
    $scope.confirmarExclusao = function(cliente){
        ClientesService.recuperar(cliente.mci, function(resposta){
			$rootScope.selecionado = resposta;
			$location.url('/exclusao');
		},function(erro){
			$scope.exibirErro(erro);
		});
    };
	 
	$scope.excluir = function(){
		ClientesService.excluir($scope.selecionado.mci, function(){
			$location.url('/clientes');
		},function(erro){
			$scope.exibirErro(erro);
		});       
	}
	
	$scope.salvar = function(){
		console.log('salvar = ' + JSON.stringify($scope.selecionado));
		if($scope.selecionado.mci){
			$scope.alterar();
		} else {
			$scope.incluir();
		}
	}


	$scope.lista();

});