angular.module('clientes').filter('sigla', function() {
    return function(texto) {
    	 if (texto) {
    		var array = texto.split(" ");
    		var sigla = '';
    		
    		for (var int = 0; int < array.length; int++) {
				sigla+= array[int].charAt(0).toUpperCase();
			}
    		
    		return sigla;
    	} else {
    		return '';
    	}
        
    };
});