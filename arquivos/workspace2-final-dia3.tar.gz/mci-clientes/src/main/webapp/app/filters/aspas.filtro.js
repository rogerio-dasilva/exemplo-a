angular.module('clientes').filter('aspas', function() {
    return function(texto) {
    	 if (texto) {
    		return '\"' + texto + '\"';
    	} else {
    		return '';
    	}
        
    };
});