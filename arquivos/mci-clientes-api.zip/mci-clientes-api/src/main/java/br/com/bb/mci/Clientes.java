package br.com.bb.mci;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement()
public class Clientes {
	private List<Cliente> listaClientes;
	
	public Clientes() {
	}
	
	public Clientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}

	public List<Cliente> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}
}
