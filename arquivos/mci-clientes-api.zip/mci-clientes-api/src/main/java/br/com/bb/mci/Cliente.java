package br.com.bb.mci;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement()
public class Cliente {
	private Integer mci;
	private String nome;
	private String documento;
	private TipoDocumento tipoDocumento;

	
	public Cliente() {
	}
	
	public Cliente(Integer codigo, String nome) {
		this.mci = codigo;
		this.nome = nome;
	}

	public Integer getMci() {
		return mci;
	}

	public void setMci(Integer codigo) {
		this.mci = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documentoIdentificacao) {
		this.documento = documentoIdentificacao;
	}

	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
}
