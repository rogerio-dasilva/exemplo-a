angular.module('clientes').controller('ClientesController', function($scope, $http) {
	
	$http.get('/mci-clientes-api/api/clientes')
	.success(function(retorno){
		$scope.clientes = retorno.listaClientes;
	}).error(function(erro){
		console.log(JSON.stringify(erro));
		var id = '#msgDanger';
        $(id).text(erro);
        $(id).css('display', 'block');
        setTimeout(function () {
            $(id).css('display', 'none');
        }, 5000);
	});
	 

});