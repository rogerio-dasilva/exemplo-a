var app = (function (undefined) {
    'use strict';

    var clienteEmEdicao;

    $(document).ajaxStart(function () {
        $('#spinner').css('display', 'block');
    });

    $(document).ajaxStop(function () {
        $('#spinner').css('display', 'none');
    });

    function monitorarAlteracoesInput(id, callback) {
        $('#' + id).bind('propertychange change click keyup input paste', callback);
    }

    function mostrarMensagemSucesso(mensagem) {
        var id = '#msgSuccess';
        $(id).text(mensagem);
        $(id).css('display', 'block');
        setTimeout(function () {
            $(id).css('display', 'none');
        }, 5000);
    }

    function mostrarMensagemErro(mensagem) {
        var id = '#msgDanger';
        $(id).text(mensagem);
        $(id).css('display', 'block');
        setTimeout(function () {
            $(id).css('display', 'none');
        }, 5000);
    }

    function validaIncluirCliente() {
        var cliente = {};
        cliente.nome = $('#inputNome').val().trim();
        cliente.documento = $('#inputDocumento').val().trim();

        if (cliente.nome && cliente.documento) {
            $('#btnIncluirCliente').prop('disabled', false);
        } else {
            $('#btnIncluirCliente').prop('disabled', true);
        }
    }

    function init() {
        monitorarAlteracoesInput('inputNome', validaIncluirCliente);
        monitorarAlteracoesInput('inputDocumento', validaIncluirCliente);

        recuperaClientes(function (resposta) {
            atualizaListaClientes(resposta.listaClientes);
        });
    }

    function recuperaClientes(callback) {
        $.get('/mci-clientes-api/api/clientes', callback);
    }

    function detalharCliente(mci) {
        $.get('/mci-clientes-api/api/clientes/' + mci, function (cliente) {
            $('#tblDetalhaCliente tbody').empty();
            $('#tblDetalhaCliente tbody').append(
                '<tr><td>' + cliente.mci + '</td><td>' + cliente.nome + '</td><td>' + cliente.documento + '</td></tr>'
            );
            $('#mdlDetalhaCliente').modal('show');
        });
    }

    function atualizaListaClientes(clientes) {
        $('#tblClientes tbody').empty();
        clientes.forEach(function (cliente) {
            $('#tblClientes tbody').append(
                '<tr><td>' + cliente.mci + '</td>' +
                '<td>' + cliente.nome + '</td>' +
                '<td><div class="btn-group" role="group">' +
                '<button type="button" class="btn btn-info" onclick="app.detalharCliente(' + cliente.mci + ')">Detalhar</button>' +
                '<button type="button" class="btn btn-info" onclick="app.colocarClienteEmEdicao(' + cliente.mci + ')">Alterar</button>' +
                '<button type="button" class="btn btn-danger" onclick="app.excluirCliente(' + cliente.mci + ')">Excluir</button>' +
                '</div></td></tr>'
            );
        });
    }

    function incluirCliente() {
        var cliente = {};
        cliente.nome = $('#inputNome').val().trim();

        if (!cliente.nome) {
            window.alert('Nome não pode ser vazio!');
            return;
        }

        cliente.documento = $('#inputDocumento').val().trim();
        if (!cliente.documento) {
            window.alert('Documento não pode ser vazio!');
            return;
        }

        $.ajax({
            url: '/mci-clientes-api/api/clientesxxx',
            type: 'POST',
            data: JSON.stringify(cliente),
            contentType: 'application/json',
            success: function () {
                mostrarMensagemSucesso('Cliente incluído com sucesso!');
                $('#inputNome').val('');
                $('#inputDocumento').val('');
                $('#mdlIncluirCliente').modal('hide');
                init();
            },
            error: function () {
                mostrarMensagemErro('Ocorreu um erro, tente mais tarde...');
            }
        });
    }

    function colocarClienteEmEdicao(mci) {
        $.get('/mci-clientes-api/api/clientes/' + mci, function (cliente) {
            clienteEmEdicao = cliente;
            $('#mciClienteEdicao').text(clienteEmEdicao.mci);
            $('#inputAlterarNome').val(clienteEmEdicao.nome);
            $('#inputAlterarDocumento').val(clienteEmEdicao.documento);
            $('#mdlAlterarCliente').modal('show');
        });
    }

    // Nova função
    function alterarCliente() {
        clienteEmEdicao.nome = $('#inputAlterarNome').val().trim();

        if (!clienteEmEdicao.nome) {
            window.alert('Nome não pode ser vazio!');
            return;
        }

        clienteEmEdicao.documento = $('#inputAlterarDocumento').val().trim();
        if (!clienteEmEdicao.documento) {
            window.alert('Documento não pode ser vazio!');
            return;
        }

        $.ajax({
            url: '/mci-clientes-api/api/clientes/' + clienteEmEdicao.mci,
            type: 'PUT',
            data: JSON.stringify(clienteEmEdicao),
            contentType: 'application/json',
            success: function () {
                $('#mdlAlterarCliente').modal('hide');
                init();
            }
        });
    }

    function excluirCliente(mci) {
        if (window.confirm('Deseja realmente excluir o cliente?')) {
            $.ajax({
                url: '/mci-clientes-api/api/clientes/' + mci,
                type: 'DELETE',
                success: function () {
                    init();
                }
            });
        }
    }

    return {
        init: init,
        detalharCliente: detalharCliente,
        incluirCliente: incluirCliente,
        alterarCliente: alterarCliente,
        colocarClienteEmEdicao: colocarClienteEmEdicao,
        excluirCliente: excluirCliente
    };
})();

app.init();